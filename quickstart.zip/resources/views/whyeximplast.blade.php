<!-- WHY EXIMPLAST? SECTION -->

<section class="whyeximplast" id="whyeximplast">

	<div class="container">

		<div class="row">

			<div class="col-md-12">

				<div class="section-title">

					<h1 class="section-heading">Чому саме гнучкі армовані шланги «ЕКСІМПЛАСТ»?</h1>
				
				</div>

			</div>

		</div>

		<div class="row whyeximplast-content">

	    	<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">
											
					<div class="icon">

						<i class="far fa-check-circle"></i>

					</div>
																					
					<div class="entry-content">

						<p>
							Гарантія якості від виробника. Постійна наявність на складі готової продукції, або максимум два дні зі складу виробника.
						</p>

					</div>

				</div>

			</div>

			<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">					
							
					<div class="icon" >

						<i class="far fa-check-circle"></i>

					</div>
						
											
					<div class="entry-content">

						<p>
							Гнучка система знижок для оптових замовлень.
						</p>

					</div>
			
				</div>

			</div>
						
			<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">
											
													
					<div class="icon" >
									
						<i class="far fa-check-circle"></i>
								
					</div>
						
											
					<div class="entry-content">

						<p>
							Індивідуальний підхід - виготовлення ексклюзивних замовлень.
						</p>

					</div>
			
				</div>

			</div>

			<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">
											
							
					<div class="icon" >
									
						<i class="far fa-check-circle"></i>
						
					</div>
						
											
					<div class="entry-content">

						<p>
							Надання всіх необхідних документів та сертифікатів.
						</p>

					</div>
							
				</div>

			</div>

		</div>

	</div>

</section>	

<!-- END OF WHY EXIMPLAST? SECTION -->