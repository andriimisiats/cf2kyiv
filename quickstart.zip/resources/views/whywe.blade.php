<!-- WHY WE? SECTION -->

<section class="whywe" id="whywe">

	<div class="container">

		<div class="row">

			<div class="col-md-12">

				<div class="section-title">

					<h1 class="section-heading">Чому ми?</h1>
				
				</div>

			</div>

		</div>

		<div class="row whywe-content">

	    	<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">
											
					<div class="icon">

						<i class="far fa-thumbs-up"></i>

					</div>
																					
					<div class="entry-content">

						<p>
							Перший роздрібно-оптовий магазин промислових шлангів в Києві!
						</p>

					</div>

				</div>

			</div>

			<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">					
							
					<div class="icon" >

						<i class="far fa-thumbs-up"></i>

					</div>
						
											
					<div class="entry-content">

						<p>
							Ми є авторизованим представником ЗСШ «ЕКСІМПЛАСТ».
						</p>

					</div>
			
				</div>

			</div>
						
			<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">
											
													
					<div class="icon" >
									
						<i class="far fa-thumbs-up"></i>
								
					</div>
						
											
					<div class="entry-content">

						<p>
							Ріжемо бухти під замовлення будь-якої потрібної для Вас довжини.
						</p>

					</div>
			
				</div>

			</div>

			<div class="col-md-3 col-sm-6 col-xs-12">

				<div class="post">
											
							
					<div class="icon" >
									
						<i class="far fa-thumbs-up"></i>
						
					</div>
						
											
					<div class="entry-content">

						<p>
							Співпрацюємо з Новою Поштою, In-Time та Нічним Експресом.
						</p>

					</div>
							
				</div>

			</div>

		</div>

	</div>

</section>	

<!-- END OF WHYWE? SECTION -->