<!-- FOOTER -->

<footer class = "footer">

	<div class="container">

		<div class="row">

			<div class="mr-auto">
					
				<p>
					© 2018 Промислові шланги
				</p>									

			</div>

			<div class = "ml-auto">

				<div class = "social-links ">

					<a href="https://www.facebook.com/pvchosecf2/" target="_blank"><i class="fab fa-facebook-f"></i></a>

				</div>
			</div>

		</div>

	</div>

	<script src="public/js/scroll.js"></script>
    <script src="public/js/filter.js"></script>
    <script src="public/js/ajax.js"></script>


</footer>

<!-- END OF THE FOOTER -->