<h2>Нове повідомлення з cf2kyiv.com.ua — Landing page</h2>

<div style="background-color: #ffffff">
	<p><strong>Email:</strong> {{ $email }}</p>
	<p><strong>Телефон:</strong> {{ $phone }}</p>
	<p><strong>Повідомлення:</strong> {{ $ajax_message }}</p>
	<br>
	<br>
	<p>© 2018 Промислові шланги</p>
</div>